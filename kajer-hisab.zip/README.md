# কাজের হিসাব
1. Firebase Console > Authentication > Email/Password চালু করে contract.ashikurrahman@gmail.com দিয়ে একটি ইউজার বানান।
2. Firestore Database > Rules ট্যাবে firestore.rules-এর লেখা বসিয়ে Publish করুন।
3. অ্যাপের সেটিং-এ ওই ইমেইল/পাসওয়ার্ড এবং Cloudinary তথ্য দিন।
