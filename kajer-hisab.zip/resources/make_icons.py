import glob, os, sys
from PIL import Image

RES = sys.argv[1]
src = Image.open("resources/icon.png").convert("RGB")

for d, s, f in [("mdpi", 48, 108), ("hdpi", 72, 162), ("xhdpi", 96, 216), ("xxhdpi", 144, 324), ("xxxhdpi", 192, 432)]:
    folder = os.path.join(RES, "mipmap-" + d)
    os.makedirs(folder, exist_ok=True)
    icon = src.resize((s, s), Image.LANCZOS)
    icon.save(os.path.join(folder, "ic_launcher.png"))
    icon.save(os.path.join(folder, "ic_launcher_round.png"))
    inner = int(f * 0.62)
    fg = Image.new("RGB", (f, f), "white")
    fg.paste(src.resize((inner, inner), Image.LANCZOS), ((f - inner) // 2, (f - inner) // 2))
    fg.save(os.path.join(folder, "ic_launcher_foreground.png"))

values = os.path.join(RES, "values")
os.makedirs(values, exist_ok=True)
with open(os.path.join(values, "ic_launcher_background.xml"), "w", encoding="utf-8") as fh:
    fh.write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#FFFFFF</color>\n</resources>\n')

for p in glob.glob(os.path.join(RES, "**", "splash.png"), recursive=True):
    w, h = Image.open(p).size
    m = int(min(w, h) * 0.4)
    canvas = Image.new("RGB", (w, h), "white")
    canvas.paste(src.resize((m, m), Image.LANCZOS), ((w - m) // 2, (h - m) // 2))
    canvas.save(p)
    print("splash", p, w, h)
print("icons done")
